import * as React from 'react';
import Card from '@mui/material/Card';
import Typography from '@mui/material/Typography';
import DashboardLayout from 'examples/LayoutContainers/DashboardLayout';
import { FormControl, Grid, Input, InputLabel } from '@mui/material';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import ArgonBox from 'components/ArgonBox';
import ArgonInput from 'components/ArgonInput';

export default function MediaCard() {
  return (
    <DashboardLayout>
      <Card>
        <Typography>Register</Typography>
         <Grid container spacing={3} mb={3} ml={2}>
         <Grid item xs={1} md={6} lg={20}>
        <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >
       <ArgonBox mb={2}>
      
        <ArgonInput type="email" placeholder="Email"  />
       </ArgonBox>
    <InputLabel >Email address</InputLabel>
      <TextField 
        placeholder='hi'
        />
        <InputLabel >Email address</InputLabel>
       <TextField
        placeholder='hi'
        />
      <div>

        <TextField
        placeholder='hi'
        />
        <TextField
        placeholder='hi'
        />
        <TextField
        placeholder='hi'
        />
       </div>
      
    </Box>
    {/* <Card sx={{ maxWidth: 345 }}></Card>
    </Grid>    
    <Grid item xs={20} md={6} lg={3}>
    <Card sx={{ maxWidth: 345 }}>
      <CardMedia
        sx={{ height: 140 }}
        image="https://media.istockphoto.com/id/502301173/photo/sports-heroes.jpg?s=612x612&w=0&k=20&c=Iski7j6mRgkYSlYF1EwBr9ClnDw2Z9SBVWukzLp9RB0="
        title="green iguana"
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
         tenice
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Lizards are a widespread group of squamate reptiles, with over 6,000
          species, ranging across all continents except Antarctica
        </Typography>
      </CardContent>
      <CardActions>
      <Button variant="contained">Add</Button>
      <Button variant="contained">View</Button>
      </CardActions>
    </Card> */}
    </Grid>
    </Grid> 
    </Card> 
    </DashboardLayout>
  );
}